<?php $__env->startSection('content'); ?>
    <?php

    ?>
    <!-- Contenido para probar el scroll -->
    <!-- Barra de navegación -->
    <header class="w-full flex justify-center bg-[#e3dba0] py-2">
        <h1 class="text-4xl">Panel de control:</h1>
    </header>

    <nav class="sticky top-0 left-0 w-full bg-gradient-to-r from-green-700 via-green-500 to-yellow-400 shadow-md z-40 ">



        <ul class="flex flex-row justify-around text-gray-700 font-medium px-4 py-3 items-center">
            <li><a href="#inicio" class="hover:text-gray-300">Usuarios</a></li>
            <li><a href="#parcelas" class="hover:text-gray-300">Parcelas</a></li>
            <li><a href="#comunidad" class="hover:text-gray-300">Eventos</a></li>
            <li>
                <button onclick="document.getElementById('logout-form').submit();"
                    class="bg-verde-oscuro text-white px-4 py-3 rounded hover:bg-green-600">
                    Cerrar sesión
                </button>
            </li>
        </ul>

    </nav>
    <main>

        <section class="h-full bg-white p-8">
            <div class="grid grid-cols-5  gap-6">
                <article class="bg-gray-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <h2 class="text-xl font-bold text-gray-800 mb-2">Usuario ID:1</h2>
                    <p class="text-gray-600 mb-2">Nombre: Juan.</p>
                    <p class="text-gray-600 mb-2">Email: Juan@juan.es.</p>
                    <p class="text-gray-600 mb-2">Fecha Creacion: Hoy.</p>
                    <p class="text-gray-600 mb-2">Parcela: Los rikitauners.</p>
                    <p class="text-gray-600 mb-2">Es admin: Si.</p>
                    <div class="flex justify-around">

                        <div onclick="" class="text-yellow-700 hover:text-yellow-600 cursor-pointer">Editar</div>
                        <div class="text-red-600 hover:text-orange-400 cursor-pointer">Eliminar</div>
                    </div>
                </article>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="bg-gray-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                        <h2 class="text-xl font-bold text-gray-800 mb-2">Usuario ID: <?php echo e($user->id); ?></h2>
                        <p class="text-gray-600 mb-2">Nombre: <?php echo e($user->name); ?></p>
                        <p class="text-gray-600 mb-2">Email: <?php echo e($user->email); ?></p>
                        <p class="text-gray-600 mb-2">Parcela: <?php echo e($user->plot_code); ?></p>
                        <p class="text-gray-600 mb-2">Es admin: <?php echo e($user->is_admin ? 'Sí' : 'No'); ?></p>
                        <div class="flex justify-around">
                            <?php if($user->id !== 1): ?>
                                <button
                                    onclick="openEditUserModal('<?php echo e($user->id); ?>', '<?php echo e($user->name); ?>', '<?php echo e($user->email); ?>', '<?php echo e($user->plot_code); ?>', '<?php echo e($user->is_admin); ?>')"
                                    class="text-yellow-700 hover:text-yellow-600 cursor-pointer">
                                    Editar
                                </button>

                                <button class="text-red-600 hover:text-orange-400 cursor-pointer">Eliminar</button>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

    </main>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('modalTitle', null, []); ?> 
             <?php $__env->slot('id', null, []); ?> 
                modal-admin-users
             <?php $__env->endSlot(); ?>
            Editar Usuario
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('modalMain', null, []); ?> 
            <?php if(session('error')): ?>
                <div class="bg-red-500 text-white p-3 rounded mb-4 text-center">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" id="editUserForm" name='action' action="<?php echo e(old('action')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="mt-3 mb-4">
                    <label for="name" class="block text-gray-700">Nombre</label>
                    <input autocomplete="off" type="text" name="name" id="name" required
                        value="<?php echo e(old('name')); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div class="mb-4">
                    <label for="email" class="block text-gray-700">Correo Electrónico</label>
                    <input autocomplete="off" type="email" name="email" id="email" required
                        value="<?php echo e(old('email')); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label for="new_password" class="block text-gray-700">Nueva contraseña</label>
                    <input autocomplete="new_password" type="password" name="new_password" id="new_password"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label for="confirm_password" class="block text-gray-700">Confirma la nueva contraseña</label>
                    <input autocomplete="off" type="password" name="new_password_confirmation" id="confirm_password"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label for="plot_name" class="block text-gray-700">Parcela</label>
                    <input type="text" name="plot_code" id="plot_name" required value="<?php echo e(old('plot_code')); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label for="is_admin" class="block text-gray-700">Es Admin</label>
                    <select name="is_admin" id="is_admin" class="w-full px-3 py-2 border rounded-lg"
                        value="<?php echo e(old('is_admin')); ?>">
                        <option value="1">Sí</option>
                        <option value="0">No</option>
                    </select>
                </div>
                <button type="submit"
                    class="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                    Modificar
                </button>
            </form>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
    </form>
    <?php if($errors->any()): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                console.log("llega aqui");
                showDialog("modal-admin-users"); // Reemplaza con el ID de tu modal
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/controlPanel.blade.php ENDPATH**/ ?>