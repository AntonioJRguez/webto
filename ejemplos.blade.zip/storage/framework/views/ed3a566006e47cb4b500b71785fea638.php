<?php $__env->startSection('content'); ?>
    <main>

        <section class="h-full bg-white p-8">
            <div class="grid grid-cols-5  gap-6">
               
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="bg-gray-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                        <h2 class="text-xl font-bold text-gray-800 mb-2">Usuario ID: <?php echo e($event->id); ?></h2>
                        <p class="text-gray-600 mb-2">Nombre: <?php echo e($event->name); ?></p>
                        <p class="text-gray-600 mb-2">Descripcion: <?php echo e($event->description); ?></p>
                        <p class="text-gray-600 mb-2">Fecha: <?php echo e($event->event_date); ?></p>
                        <p class="text-gray-600 mb-2">Aforo: <?php echo e($event->capacity); ?></p>
                        <p class="text-gray-600 mb-2">Lugar del evento: <?php echo e($event->location); ?></p>
                        <div class="flex justify-around">

                                <a href="<?php echo e(route('admin.update.event', compact('event'))); ?>">
                                    <button class="text-yellow-700 hover:text-yellow-600 cursor-pointer">
                                        Editar
                                    </button>
                                </a>
                                <button onclick="toggleDialog('modal-delete-event<?php echo e($event->id); ?>')"
                                    class="text-red-600 hover:text-orange-400 cursor-pointer">Eliminar</button>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('admin.create.event')); ?>" class="flex items-center">
                    <article
                        class="bg-green-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow flex justify-center items-center cursor-pointer active:scale-95 select-none">
                        <p>Añadir evento.</p>
                    </article>
                </a>
            </div>
        </section>

    </main>

    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($event->id !== 1): ?>
            <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('modalTitle', null, []); ?> 
                     <?php $__env->slot('id', null, []); ?> 
                        modal-delete-event<?php echo e($event->id); ?>

                     <?php $__env->endSlot(); ?>
                    ¿Seguro que quieres borrar el evento?
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('modalMain', null, []); ?> 
                    <?php if(session('error')): ?>
                        <div class="bg-red-500 text-white p-3 rounded mb-4 text-center">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" id="deleteEventForm" name='action'
                        action="<?php echo e(route('admin.delete.event', $event->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" onclick="toggleDialog('modal-delete-event<?php echo e($event->id); ?>')"
                            class="w-full bg-slate-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                            No
                        </button>
                        <button type="submit"
                            class="w-full bg-red-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                            Si
                        </button>
                    </form>
        <?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-controlPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/controlpanel/events-controlPanel.blade.php ENDPATH**/ ?>