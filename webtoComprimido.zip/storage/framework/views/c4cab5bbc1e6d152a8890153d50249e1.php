<?php $__env->startSection('content'); ?>
    <main class="mt-20 flex-grow flex flex-col items-center h-full min-h-screen w-full">
        <div class="flex flex-col w-[95%] md:w-[80%] h-full bg-gris-claro rounded-lg p-3 m-2">
            <div class="w-full flex justify-center">
                <h1 class="text-6xl font-extrabold text-gris-profundo climate">
                    Eventos
                </h1>
            </div>
            
            <?php if($events->isEmpty()): ?>
                <div class="flex h-20 items-center justify-center">
                    <p>No hay ningun evento disponible.</p>
                </div>
            <?php else: ?>
                <section class="grid grid-cols-1 sm:grid-cols-3 gap-6 p-6">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $asistants = 0;
                        ?>
                        
                        <article
                            class="border-2 border-green-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 bg-white flex flex-col h-full">
                            <div class="flex flex-col items-center p-4 border-b border-green-100">
                                <h2 class="font-bold text-lg text-gray-800 mb-3 text-center"><?php echo e($event->name); ?></h2>
                                <div class="h-48 overflow-hidden flex items-center justify-center bg-gray-50 mx-auto">
                                    <?php if(!is_null($event->image_id)): ?>
                                        <?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => ''.e($event->image_id).'','class' => 'h-full w-auto max-w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => ''.e($event->image_id).'','class' => 'h-full w-auto max-w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
                                    <?php else: ?>
                                        <?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => 'noimage','class' => 'h-full w-auto max-w-full object-contain p-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => 'noimage','class' => 'h-full w-auto max-w-full object-contain p-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Contenido con altura fija para alinear en grid -->
                            <div class="p-4 flex flex-col w-full h-full justify-end">
                                <p
                                    class="border border-green-100 rounded-lg p-3 bg-green-50 text-gray-700 mb-4 text-sm flex-grow">
                                    <?php echo e($event->description); ?></p>
                                <?php $__currentLoopData = $event->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $asistants++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Detalles del evento - alineados -->
                                <div class="space-y-2 text-sm text-gray-600 p-4">
                                    <div class="flex justify-between">
                                        <span class="col-span-2 font-medium text-gray-700">Cupo:</span>
                                        <span class="col-span-3"><?php echo e($asistants); ?>/<?php echo e($event->capacity); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="col-span-2 font-medium text-gray-700">Fecha:</span>
                                        <span
                                            class="col-span-3"><?php echo e(\Carbon\Carbon::parse($event->event_date)->translatedFormat('d/m/Y H:i')); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="col-span-2 font-medium text-gray-700">Duración:</span>
                                        <span class="col-span-3"><?php echo e($event->duration); ?> horas</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="col-span-2 font-medium text-gray-700">Lugar:</span>
                                        <span class="col-span-3 break-words"><?php echo e($event->location); ?></span>
                                    </div>
                                </div>

                                <!-- Botones (manteniendo tus clases originales) -->
                                <form method="POST" id="editTasksForm" action="<?php echo e(route('toggle.assistant')); ?>"
                                    class="mt-4">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <input type="hidden" name="eventId" id="eventId" value="<?php echo e($event->id); ?>">
                                    <?php if($event->users->contains('id', Auth::id())): ?>
                                        <button type="submit" class="btn-red w-full">Desapuntarme</button>
                                    <?php else: ?>
                                        <?php if($asistants < $event->capacity): ?>
                                            <button type="submit" class="btn-green w-full">Apuntarme</button>
                                        <?php else: ?>
                                            <button class="btn-gray w-full">Evento lleno</button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                </section>
                <div class="mt-4 p-5">
                    <?php echo e($events->links()); ?>

                </div>
            <?php endif; ?>
        </div>


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto-app\resources\views/events.blade.php ENDPATH**/ ?>