<?php $__env->startSection('content'); ?>
    <main class="mt-20 flex justify-center ">
        <div class="flex flex-col w-[80%] h-full bg-gris-claro rounded-lg p-6">
            <div class="w-full flex flex-col justify-center">
                <h1 class= "text-xl">Eventos</h1>
            </div>


            <section class="grid grid-cols-3 gap-6 p-6">
                <?php
                
                ?>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $asistants = 0;
                    ?>
                    <article class="border-2 border-verde-claro rounded-lg p-2">
                        <div class=" flex flex-col items-center">
                            <h2 class="font-bold"><?php echo e($event->name); ?></h2>
                            <?php if(!is_null($event->image_id)): ?>
                                <?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => ''.e($event->image_id).'','class' => 'w-72']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => ''.e($event->image_id).'','class' => 'w-72']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => 'noimage','class' => 'w-72']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => 'noimage','class' => 'w-72']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
                            <?php endif; ?>

                        </div>
                        <div class="p-2 flex flex-col items-center">
                            <img src="" alt="">
                            <p class="border-1 rounded-s p-2 bg-verde-claro"><?php echo e($event->description); ?></p>
                            <?php $__currentLoopData = $event->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $asistants++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                Cupo de asistentes: <?php echo e($asistants); ?>/<?php echo e($event->capacity); ?>

                            </div>
                            <div>
                                Fecha evento: <?php echo e($event->event_date); ?>

                            </div>
                            <div>
                                Duración(Horas): <?php echo e($event->duration); ?>

                            </div>
                            <div>
                                Lugar: <?php echo e($event->location); ?>

                            </div>
                            <?php if($event->users->contains('id', Auth::id())): ?>
                                <button class="btn-red">Desapuntarme</button>
                            <?php else: ?>
                                <?php if($asistants < $event->capacity): ?>
                                   <button class="btn-green">Apuntarme</button>
                                <?php else: ?>
                                    <button class="btn-gray">Evento lleno</button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                <?php if (isset($component)) { $__componentOriginal31347fa367ab074d51def314d5711b57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31347fa367ab074d51def314d5711b57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Upload Files <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31347fa367ab074d51def314d5711b57)): ?>
<?php $attributes = $__attributesOriginal31347fa367ab074d51def314d5711b57; ?>
<?php unset($__attributesOriginal31347fa367ab074d51def314d5711b57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31347fa367ab074d51def314d5711b57)): ?>
<?php $component = $__componentOriginal31347fa367ab074d51def314d5711b57; ?>
<?php unset($__componentOriginal31347fa367ab074d51def314d5711b57); ?>
<?php endif; ?>



                


            </section>
            <div class="mt-4 p-5">
                <?php echo e($events->links()); ?>

            </div>
        </div>


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/events.blade.php ENDPATH**/ ?>