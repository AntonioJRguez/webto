<?php $__env->startSection('content'); ?>
    <!-- Contenido para probar el scroll -->

    <h1>Panel de control:</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-nosession', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/ControlPanel.blade.php ENDPATH**/ ?>