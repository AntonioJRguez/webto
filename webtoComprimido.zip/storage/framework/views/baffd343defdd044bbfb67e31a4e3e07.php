<!doctype html>
<html class="!scroll-smooth">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    
    

</head>

<body class="circle-pattern">
    <div class="z-50 bg-verde-claro">
        <!-- Header de la página -->
        <header class="top-0 left-0 w-full h-[120px]  ">
            <div class="container mx-auto flex items-center justify-center px-4 py-2 belittle">
                <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('images/webtologo.png')); ?>" alt="Logo" class="h-[100px]"></a>
            </div>
        </header>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

</body>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

</html>
<?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/layouts/app-basic.blade.php ENDPATH**/ ?>