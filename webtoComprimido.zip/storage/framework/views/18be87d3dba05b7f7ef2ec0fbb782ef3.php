
<?php $__env->startSection('content'); ?>


    <main class="mt-20 flex justify-center ">
        <div class="flex flex-col items-center w-[80%] h-full bg-gris-claro rounded-lg p-4">
            
            
            </div>


    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/newTask.blade.php ENDPATH**/ ?>