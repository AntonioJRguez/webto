<?php $__env->startSection('content'); ?>
    <!-- Contenido para probar el scroll -->

    <section id="inicio" class="flex justify-center items-center">
        <div class="bg-white p-8 rounded-lg shadow-lg w-auto">
            <h2 class="text-2xl font-bold text-center mb-4">Registro</h2>
    
            <?php if($errors->any()): ?>
                <div class="mb-4 p-2 bg-red-200 text-red-700 rounded">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
    
            <form action="<?php echo e(route('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="block text-gray-700">Nombre</label>
                    <input type="text" name="name" class="w-full p-2 border rounded" value="<?php echo e(old('name')); ?>" required>
                </div>
    
                <div class="mb-4">
                    <label class="block text-gray-700">Email</label>
                    <input type="email" name="email" class="w-full p-2 border rounded" value="<?php echo e(old('email')); ?>" required>
                </div>
    
                <div class="mb-4">
                    <label class="block text-gray-700">Teléfono</label>
                    <input type="text" name="phone_number" class="w-full p-2 border rounded" value="<?php echo e(old('phone_number')); ?>">
                </div>
    
                <div class="mb-4">
                    <label class="block text-gray-700">Código de parcela</label>
                    <input type="text" name="plot_code" class="w-full p-2 border rounded" required>
                </div>
    
                <div class="mb-4">
                    <label class="block text-gray-700">Contraseña</label>
                    <input type="password" name="password" class="w-full p-2 border rounded" required>
                </div>
    
                <div class="mb-4">
                    <label class="block text-gray-700">Confirmar Contraseña</label>
                    <input type="password" name="password_confirmation" class="w-full p-2 border rounded" required>
                </div>
    
                <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">
                    Registrarse
                </button>
            </form>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/register.blade.php ENDPATH**/ ?>