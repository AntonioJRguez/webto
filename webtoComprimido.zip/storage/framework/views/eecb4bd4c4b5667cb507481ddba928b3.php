<?php $__env->startSection('content'); ?>
    <?php

    ?>
   
    <main>

        <section class="h-full bg-white p-8">
        </section>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-controlPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webto1\webto-app\resources\views/controlpanel/controlPanel.blade.php ENDPATH**/ ?>